/*
~~ Thrower Settings Documentation ~~

 ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

End Pos Ground Level ~ (default = 0)

* After hitting the target final ending ground pos
z axis which is hight calculated as the initial z position of the source object for example
if source obj init pos is (x1,y1,50) after you throw it ground pos will be (x2,y2,50)

* With this property you can adjust the ending z pos for example you can give -300
for the ball end up in a lower height that its initial height


!!! When you change the default value, the road throw obejct will follow is going to get longer 
that will speed up the ball movement but it only effects after hitting the target faze

!!! Dont give positive values if you dont want your source object to bounce upwards

~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

Gravity Force

* This property is making the throw realistic if you set this property as 0
throw object will follow a straight path to target

* Higher values means higher throw angle check the demonstrations below

O -> Throw Object
T -> Target
X -> key points

<_> Lower Gravity Value for example -400                     
             T     X 
        X               X
   X                         X
O                                X           
---------------------------

<_> Greater Gravity Value for example -1000                         
            
         X
     X   
            X
   X         T     
              X        
 X                        
O               X             
---------------------------

~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

Decomposition Indexs Path -> Target && Path -> Ground

* Throw Object follows a path that starts on its own position then ends at a calculated 
ground pos. A mapping algorithm calculates the spherical dataset from init pos to end pos
there are lots of positions on this map and if we try to lerp throught all of this points
our engine will crash, so for optimization reasons we take the key points on the map 
that we can follow, this way we follow way more less positions while moving to the end position.

* Decomposition Index is defining how many key points you want for the path 

* Higher Values has better performance but poor smoothnes for example 
if you set 1 as value, throw object will watch a straight line 

* Higher Values also increase speed because higher values means that you have less key points

* Since Decomposition Index effects speed you can adjust diffrent speed options
for before hitting the target faze and after hitting target faze for example if you 
use 0,1 for before faze and 0,3 for after stage you can make the after faze faster.
 
~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~

Overall Speed

* Since almost every setting is effecting speed in diffrent fazes after you find your proper
throw settings you can use this property to adjust the overall speed

~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~ ~~






*/