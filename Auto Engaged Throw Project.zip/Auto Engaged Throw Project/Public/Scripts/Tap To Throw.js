// -----JS CODE-----
//@input SceneObject ball
//@input SceneObject target 
//@input Component.ScriptComponent thrower

let throwObj

let throwed = false;

const targetPos = script.target.getTransform().getWorldPosition()

const onStart = script.createEvent('OnStartEvent')
onStart.bind(function(){
 throwObj = script.thrower.api.createThrowObject(script.ball);    
});

const tap = script.createEvent('TapEvent')
tap.bind(function(){   
 if(!throwed){          
  throwObj.throwTo(targetPos,onThrowEnd,onHitTarget);       
 }   
 else{      
  throwObj.reset()      
 }
 throwed = !throwed;   
});

const onThrowEnd = function(){
 print('End')
}
const onHitTarget = function(){
 print('Hit')    
}
