//@ui {"widget":"label", "label":"Settings"}
//@ui {"widget":"separator"}
//@input float endPosGroundLevel = 0
//@input int gravity = 100 {"label":"Gravity Force"}
//@input bool stopOnTarget = false
//@input float decompositionIndexPathToTarget = 0.1 {"widget":"slider", "min":0.01, "max":1.0, "step":0.01}
//@input float decompositionIndexPathToGround = 0.1 {"widget":"slider", "min":0.01, "max":1.0, "step":0.01}
//@ui {"widget":"label", "label":"Important!"}
//@ui {"widget":"label", "label":"Decomposition indexs also effect speed"}
//@ui {"widget":"label", "label":"Use this property if you set the correct decomposition indexs for your project"}
//@input float speed = 1.0 {"widget":"slider", "min":0.1, "max":10.0, "step":0.01, "label":"Overall Speed"}



class transformHelper {
 constructor(sceneObject){      
  this.sceneObject = sceneObject;   
  this.transform = this.sceneObject.getTransform();                      
  this.orgPos = this.getPos()     
  this.orgRot = this.getRot()      
 }   
 getPos(){
  return this.transform.getWorldPosition()       
 }
 getRot(){
  return this.transform.getWorldRotation()       
 }
 setPos(pos){
  this.transform.setWorldPosition(pos)       
 }
 setRot(rot){
  this.transform.setWorldRotation(rot)       
 }
 reset(){
  this.setPos(this.orgPos)
  this.setRot(this.orgRot)      
 }   
}

class ThrowObject extends transformHelper{
    
  throwTo(endPos, callbackFn, onHitTarget){ 

   const throwObj = this;           
   const groundPos = calculateGroundPos(throwObj.getPos(),endPos);       
        
   const pathToTarget = getSphericDataSet(throwObj.getPos(), endPos, script.decompositionIndexPathToTarget);
   const pathToGround = getSphericDataSet(endPos, groundPos, script.decompositionIndexPathToGround);

   const path = script.stopOnTarget ? pathToTarget : pathToTarget.concat(pathToGround)         
        
   const move = function(){
    if(path.length === 0) {   
     if(typeof callbackFn === 'function'){ 
      callbackFn()               
     }                    
     return                
    }
    let stage = path.length;         
    let toPos = path.shift();
    let initPos = throwObj.getPos()  
            
    let t=0;
    let lerpedPos;
    let readyToEnd = false;        
          
    const speed = 5 * script.speed;        

    const update = script.createEvent('UpdateEvent');
    update.bind(function(){     
     if(t > 1){
      t = 1;
      readyToEnd = true;              
     }           
 
     lerpedPos = vec3.lerp(initPos,toPos,t);
     t += getDeltaTime() * speed * Math.sqrt(stage,2);
     throwObj.setPos(lerpedPos);
                                
     if(readyToEnd){                
      script.removeEvent(update);   
      if(toPos === endPos && onHitTarget && typeof onHitTarget === 'function'){
       onHitTarget()                         
      }                    
      move();              
      return              
     }
                
    });        
   }
   move()     
 }        
}

const calculateGroundPos = function(initPos,endPos){
 const finalGroundPosition = vec3.zero()

 finalGroundPosition.x = initPos.x + (endPos.x-initPos.x) * 2   
 finalGroundPosition.y = initPos.y + script.endPosGroundLevel;   
 finalGroundPosition.z = initPos.z + (endPos.z-initPos.z) * 2        
    
 return finalGroundPosition;     
} 

const getSphericDataSet = function(initPos,endPos,tVal){    
 const dataSet = [];
 
 let t = tVal === 0 ? 0.1 : tVal;
 let velocity = vec3.one();
 let pos = vec3.zero();
 const g = script.gravity 
 const tEnd = 1;   
   
 velocity.x = ((initPos.x - endPos.x) / tEnd) * -1
 velocity.y = ((initPos.y - endPos.y - (.5 * g * Math.pow(tEnd,2))) / tEnd) * -1
 velocity.z = ((initPos.z - endPos.z) / tEnd) * -1
    
 while(t<=tEnd){            
  pos.x = initPos.x + velocity.x * t;
  pos.y = initPos.y + velocity.y * t - (.5 * g * Math.pow(t,2) );
  pos.z = initPos.z + velocity.z * t;      
  t += t;  
      
  dataSet.push(new vec3(pos.x,pos.y,pos.z));      
 }
 dataSet.push(endPos);
      
 return dataSet;   
}

const createThrowObject = function(obj){
 return new ThrowObject(obj)  
}
script.api.createThrowObject = createThrowObject;
